public class example {
    public static void main(String[] args) {
        int total = 0;
        for(int i=0; i<args.length; i++){
            total += Integer.parseInt(args[i])*2;
        }
        System.out.println(total);
    }
}
